// app/you/_layout.js
import { Stack } from 'expo-router';

export default function youLayout() {
  return <Stack screenOptions={{ headerShown: true }} />;
}
