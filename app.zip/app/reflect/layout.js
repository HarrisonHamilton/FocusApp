// app/reflect/_layout.js
import { Stack } from 'expo-router';

export default function ReflectLayout() {
  return <Stack screenOptions={{ headerShown: true }} />;
}
