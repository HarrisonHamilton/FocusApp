import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function ReflectHome() {
  const router = useRouter();

  const menuItems = [
    { label: 'Journal Entry', icon: 'book-outline', path: '/reflect/journal' },
    { label: 'Emotion Log', icon: 'happy-outline', path: '/reflect/emotions' },
    { label: 'Vent a Thought', icon: 'megaphone-outline', path: '/reflect/vent' },
    { label: 'Insights (Coming Soon)', icon: 'analytics-outline', path: null },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🧠 Reflect</Text>

      {menuItems.map((item, index) => (
        <TouchableOpacity
          key={index}
          style={[styles.card, !item.path && styles.disabled]}
          onPress={() => item.path && router.push(item.path)}
          disabled={!item.path}
        >
          <Ionicons name={item.icon} size={24} color="white" />
          <Text style={styles.cardText}>{item.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    padding: 24,
    paddingTop: 60,
  },
  title: {
    color: 'white',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#1e1e1e',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  disabled: {
    opacity: 0.5,
  },
  cardText: {
    color: 'white',
    fontSize: 18,
    marginLeft: 12,
  },
});
