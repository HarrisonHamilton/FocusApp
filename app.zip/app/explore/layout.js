// app/explore/_layout.js
import { Stack } from 'expo-router';

export default function exploreLayout() {
  return <Stack screenOptions={{ headerShown: true }} />;
}
