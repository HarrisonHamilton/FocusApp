import { Slot } from 'expo-router';

export default function ExploreLayout() {
  // This disables tabs inside explore folder by just rendering nested content
  return <Slot />;
}
