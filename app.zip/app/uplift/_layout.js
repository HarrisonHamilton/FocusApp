import { Slot } from 'expo-router';

export default function UpliftLayout() {
  // This disables tabs inside reflect folder by just rendering nested content
  return <Slot />;
}
